require('./release/angular-recaptcha.js');
module.exports = 'vcRecaptcha';
